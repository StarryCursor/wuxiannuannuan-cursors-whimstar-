﻿无限暖暖-02 Windows 鼠标指针包 (v5)
作者: [StarryCursor](https://github.com/StarryCursor)

【安装】右键 install.inf → 安装 → UAC → main.cpl → 指针 → 方案"无限暖暖-02" → 确定
【卸载】main.cpl 切回 Windows 默认，管理员 cmd:
  rmdir /S /Q "%SystemRoot%\Cursors\NuanNuan-02"
  reg delete "HKCU\Control Panel\Cursors\Schemes" /v "无限暖暖-02" /f

包含 10 个 Windows 光标（未含 move/unavailable，沿用系统默认）。
openhand/closedhand 在 Windows 标准方案无槽位，如需使用请到鼠标设置手动浏览。
