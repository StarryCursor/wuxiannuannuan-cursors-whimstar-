﻿无限暖暖-02 Windows 鼠标指针包 (v6)
作者: [StarryCursor](https://github.com/StarryCursor)

【v6 更新】
新增 4 个标准光标：help（帮助）、move（移动）、forbidden（不可用）、appstarting（后台运行）
新增 8 个单向 resize 光标（不在 Windows 标准方案，需手动指定）

【安装】右键 install.inf → 安装 → UAC → main.cpl → 指针 → 方案"无限暖暖-02" → 确定

【现在已经覆盖的 Windows 系统光标槽位（共 13 个）】
- Normal Select (正常选择)         arrow.cur
- Help Select (帮助选择)           help.cur          ✨新增
- Working in Background (后台运行) appstarting.cur   ✨新增
- Busy (忙碌)                      busy.cur
- Text Select (文本选择)           ibeam.cur
- Unavailable (不可用)             forbidden.cur     ✨新增
- Vertical Resize ↕                size_ns.cur
- Horizontal Resize ↔              size_we.cur
- Diagonal Resize 1 ↖↘             size_nwse.cur
- Diagonal Resize 2 ↗↙             size_nesw.cur
- Move (移动)                      move.cur          ✨新增
- Link Select (链接选择)           link.cur

【额外提供的 .cur 文件】
openhand.cur, closedhand.cur — 张开手、抓握（Windows 标准方案无此槽位）
size_n/s/e/w.cur — 单向 resize
size_ne/nw/se/sw.cur — 单向对角 resize
如需使用：控制面板 → 鼠标 → 指针 → 在自定义列表里选中对应项 → 浏览 → 选这些 .cur

【卸载】main.cpl 切回 Windows 默认；
管理员 cmd:
  rmdir /S /Q "%SystemRoot%\Cursors\NuanNuan-02"
  reg delete "HKCU\Control Panel\Cursors\Schemes" /v "无限暖暖-02" /f
